module.exports = {
    HOST: "localhost"
    USER: "admin1"
    PASSWORD: "Sf_A:st:KM8"
    DB: "modul"
}